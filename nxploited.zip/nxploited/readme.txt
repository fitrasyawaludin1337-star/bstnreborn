=== Nxploited ===
Contributors: nxploited
Tags: nxploited
Requires at least: 4.0
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later

Nxploited

== Description ==

Nxploited

== Installation ==

1. Upload to /wp-content/plugins/nxploited
2. Activate
