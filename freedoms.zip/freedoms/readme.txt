=== Freedoms ===
Contributors: Freedoms
Tags: Freedoms
Requires at least: 4.0
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later

Freedoms

== Description ==

Freedoms

== Installation ==

1. Upload to /wp-content/plugins/freedoms
2. Activate
